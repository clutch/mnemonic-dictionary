'use strict';

angular.module('mnemonicDictionaryApp.util', []);
